package com.sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokemanApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokemanApplication.class, args);
	}

}
