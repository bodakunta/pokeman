/*
package com.sb.client;

*/
/**
 * <p>Title: $[Name]</p>
 *
 * <p>Description: TODO</p>
 *
 * <p>Copyright: copyright (c) 2021</p>
 * <p>Company: Perosnal</p>
 *
 * @author Shankar Bodakunta
 *//*

//@FeignClient(value = "pokemon", url = "https://pokeapi.co/api/v2/pokemon/")

public interface PokemanApiClient {

*/
/*    @RequestMapping(method = RequestMethod.GET, value = "/{pokemanId}", produces = "application/json")
    Object getPokeman(@PathVariable("pokemanId") int pokemanId);*//*

}
*/
